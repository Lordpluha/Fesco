<?php
	
	echo "Nice!";

?>