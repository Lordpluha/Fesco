jQuery(document).ready(function($) {
	window.setTimeout(function() {
		$('.preloader').removeClass('active');
	}, 100);
});